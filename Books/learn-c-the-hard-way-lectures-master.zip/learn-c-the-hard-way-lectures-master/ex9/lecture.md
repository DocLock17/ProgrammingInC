Learn C The Hard Way
=======

Exercise 9
----

While-Loop and Boolean Expressions



The Plan
====

You first loop shall be the *while*:

    while(TEST) {
        CODE;
    }



The Code
====



The Analysis
====




Breaking It
====

* Forget to initialize the *int i*.
* Forget to do an i++ and make it run forever.



Extra Credit
====

* Make the loop count backward by using ``i--`` to start
  at 25 and go to 0.
* Write a few more complex ``while-loops`` using what you know
  so far.



End Of Lecture 9
=====



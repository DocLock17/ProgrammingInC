#include <stdio.h>

int main(int argc, char *argv[])
{
    int i;
    while (i < 25) {
        printf("%d\n", i);
        i++;
    }

    return 0;
}

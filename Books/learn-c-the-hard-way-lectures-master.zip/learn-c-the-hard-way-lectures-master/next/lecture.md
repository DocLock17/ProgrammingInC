
Learn C The Hard Way
=======

Next Steps
----

Goodbye Friendly Friends



The Plan
====

Some parting words on your new journey.



The Purpose
====

Advice for the future.



Read More Books On C
====



Don't Make More C Code
====



Learn 4 More Programming Languages
====



Study Algorithms For Real
====



Don't Take This Too Seriously
====



Arrogant Programmers Are Terrible Programmers
====



Learn To Paint
====



End of Learn C The Hard Way
=====

Email help@learncodethehardway.org or ask @lzsthw on Twitter.


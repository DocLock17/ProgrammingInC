Learn C The Hard Way
=======

Exercise 4
----

Using a Debugger



The Plan
====

* See how GDB works (LLDB on OSX).
* Look at memory checkers like Valgrind and AddressSanitizer.
* Cover the quick reference.
* Debug a program.



Using GDB
====



Using LLDB
====



Using Valgrind
====



Using Lint
====



Using AddressSanitizer
====

You neeed clang for this.



"The Debugger"
====

When I say "the debugger" in the book I mean to use GDB, but use 
every tool you can find that helps.



End Of Lecture 4
=====



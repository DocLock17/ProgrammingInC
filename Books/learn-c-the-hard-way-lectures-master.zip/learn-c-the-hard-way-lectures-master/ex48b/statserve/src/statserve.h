#ifndef _statserve_h
#define _statserve_h

int echo_server(const char *host, const char *port);

#endif

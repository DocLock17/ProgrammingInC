Learn C The Hard Way
=======

Exercise 48
----

A Simple Network Server:

Solution
----



The Plan
====

Show you how I solved the *statserve* project.



The Purpose
====

Watch me solve the first project quickly, then review the code.



The Setup
====

First I need to install liblcthw since I'll be using that.

Then I make the project skeleton and get something, anything going.



The Server
====

Then I just get it accepting a connection.



The Echo
====

Then I decided to just make it echo back what I type.



The Final Code
====



End Of Lecture 48b
=====



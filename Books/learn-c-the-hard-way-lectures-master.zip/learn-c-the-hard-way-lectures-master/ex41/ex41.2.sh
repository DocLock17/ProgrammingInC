mkdir devpkg
cd devpkg
touch README Makefile

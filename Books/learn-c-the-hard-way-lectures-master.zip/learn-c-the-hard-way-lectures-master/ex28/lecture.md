Learn C The Hard Way
=======

Exercise 28
----

Intermediate Makefiles



The Plan
====

* Learn how to create a project skeleton to make starting easier.
* Learn more advanced GNU make tricks.



The Skeleton
====

The video is probably easier to follow than the book.
Watch me do this.



Using The Skeleton
====

Now I'll use the skeleton to start a simple project for the next exercise.



The Analysis
====

Let's look at Makefile in depth.



Extra Credit
====



End Of Lecture 28
=====



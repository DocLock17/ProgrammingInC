Learn C The Hard Way
=======

Exercise 42
----

Stacks and Queues



The Plan
====

Create a Stack and Queue data structure from just the unit tests.



PAUSE!
====

WARNING!  Stop the video now and try to solve this yourself!

I'll show you how I did it after you try it (or you can cheat).



Code Review
====



Extra Credit
====

* Implement ``Stack`` using ``DArray`` instead of ``List``, but without changing the unit test.  That means you'll have to create your own ``STACK_FOREACH``.



End Of Lecture 42
=====



/* labs function */
#include <stdlib.h>

long (labs)(long i)
	{	/* compute absolute value of long argument */
	return ((i < 0) ? -i : i);
	}

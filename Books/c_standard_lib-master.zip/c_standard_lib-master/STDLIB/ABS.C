/* abs function */
#include <stdlib.h>

int (abs)(int i)
	{	/* compute absolute value of int argument */
	return ((i < 0) ? -i : i);
	}

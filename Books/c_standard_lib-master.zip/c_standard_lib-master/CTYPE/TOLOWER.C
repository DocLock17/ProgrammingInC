/* tolower function */
#include <ctype.h>

int (tolower)(int c)
	{	/* convert to lowercase character */
	return (_Tolower[c]);
	}

/* asin function */
#include <math.h>

double (asin)(double x)
	{	/* compute asin(x) */
	return (_Asin(x, 0));
	}

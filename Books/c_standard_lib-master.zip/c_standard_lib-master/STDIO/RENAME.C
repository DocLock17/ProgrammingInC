/* rename function -- dummy version */
#include "xstdio.h"

int (rename)(const char *oldnm, const char *newnm)
	{	/* rename a file */
	return (-1);
	}

/* remove function -- dummy version */
#include "xstdio.h"

int (remove)(const char *filename)
	{	/* remove a file */
	return (-1);
	}

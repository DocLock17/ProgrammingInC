/* _Getmem function -- dummy version */
#include "xalloc.h"

void *_Getmem(size_t size)
	{	/* allocate raw storage */
	return (NULL);
	}

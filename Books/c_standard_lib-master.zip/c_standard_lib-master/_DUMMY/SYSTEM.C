/* system function -- dummy version */
#include <stdlib.h>

int (system)(const char *s)
	{	/* send text to system command line processor */
	return (0);
	}

/* _Fgpos function -- dummy version */
#include "xstdio.h"

long _Fgpos(FILE *str, fpos_t *ptr)
	{	/* position a file */
	return (EOF);
	}

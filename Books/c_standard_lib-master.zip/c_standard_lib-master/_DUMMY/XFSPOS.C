/* _Fspos function -- dummy version */
#include "xstdio.h"

int _Fspos(FILE *str, const fpos_t *ptr, long *off, int way)
	{	/* position a file */
	return (EOF);
	}

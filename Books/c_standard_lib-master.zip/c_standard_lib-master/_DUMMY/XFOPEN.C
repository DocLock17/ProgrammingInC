/* _Fopen function -- dummy version */
#include "xstdio.h"

int _Fopen(const char *path, unsigned int smode,
	const char *mods)
	{	/* open a file */
	return (-1);
	}
